import { View, StyleSheet } from "react-native";
import Color from "./Color";
const ProgressBar = () => {
  return <View></View>;
};

export default ProgressBar;

const styles = StyleSheet.create({});
