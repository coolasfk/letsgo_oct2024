const Color = {
  fontBodyColor: "#9E8142",
  myBgColor: "#C7D8C5",
  color1: "#E3EBE2",
  color2: "#264224",
  color3: "#A4C7A0",
  color4: "#77CCB2",
  color5: "#99E8CD",
  color6: "#82C76D",
  color7: "#68BAC4",
  color8: "#BFA772",
  color9: "#85929A",
  color10: "#629150",
};

export default Color;
